package com.rocketseat.planner.activity;

public record ActivityRequestPayload(String title, String occurs_at) {
    
}
