package com.rocketseat.planner.link;

public record LinkRequestPayload(String title, String url) {
}
