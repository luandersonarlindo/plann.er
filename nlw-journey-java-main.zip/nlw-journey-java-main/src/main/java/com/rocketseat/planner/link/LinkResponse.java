package com.rocketseat.planner.link;

import java.util.UUID;

public record LinkResponse(UUID linkId) { 
}
