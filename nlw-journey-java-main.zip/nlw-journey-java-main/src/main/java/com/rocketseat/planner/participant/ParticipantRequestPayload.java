package com.rocketseat.planner.participant;

public record ParticipantRequestPayload(String name, String email) {
    
}
